import pandas as pd
import nltk
from nltk import sent_tokenize
from nltk import word_tokenize
from nltk.corpus import stopwords
from nltk.probability import FreqDist
from nltk.stem import SnowballStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from wordcloud import WordCloud, ImageColorGenerator
import requests
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from sklearn.svm import SVC, LinearSVC

'''
The targed of the following preprocessing is to create a Bag-of-Words representation of the data. The steps will execute as follows:

1. Cleansing
        Remove URLs
        Remove usernames (mentions)
        Remove tweets with *Not Available* text
        Remove special characters
        Remove numbers
2. Text processing
        Tokenize
        Transform to lowercase
        Stem
3. Build word list for Bag-of-Words
'''

def convert_list_to_string(org_list, seperator=' '):
    """ Convert list to string, by joining all item in list with given separator.
        Returns the concatenated string """
    return seperator.join(org_list)

missing_values = ["n/a", "na", "--"]
Data = pd.read_csv('https://raw.githubusercontent.com/dD2405/Twitter_Sentiment_Analysis/master/train.csv',na_values = missing_values)
# It ensuers that there are no more null values presented in the tweet and label column
print("------------------Checking the missing values---------------------------------")
print(Data['tweet'].isnull())
print(Data['label'].isnull())
print(Data.head(10))
print("--------------------Checking null values--------------------------------------")
# Remove if any null values if any
modifiedDF=Data.fillna(" ")
# verify no longer null values presented in the data
print(modifiedDF.isnull().sum())
print("-------------------------------------------------------------------------------")

# Read the tweet text only  :
text = pd.Series(modifiedDF.tweet.head(100)).to_string()
data=text
#Tokenize the text by sentences :
sentences = sent_tokenize(text)
#How many sentences are there? :
print ("number of sentences",len(sentences))
#Tokenize the text with words :
words = word_tokenize(text)
#Print words :
print(words)
#How many words are there? :
print("number of words",len(words))
print("\n")

# Preprocessing the data which includes removing puncuations,handers, numbers, special characters, stop words
#Empty list to store words:
words_no_punc = []

#Removing punctuation marks, handler @,numbers, special characters, stop words :
for w in words:
    if w.isalpha():
        words_no_punc.append(w.lower())
#Print the words without punctution marks :
print(words_no_punc)

print("---------------------------------Before removing stop words frequency distribution---------------------\n")
fdist= FreqDist(words_no_punc)
print(fdist.most_common(10))
#Plot the graph for words_no_punc using fdist :
import matplotlib.pyplot as plt
print(fdist.plot(10,title="Before removing Stop words"))
#
print("---------------------------------After removing stop words frequency distribution---------------------\n")
stopwords = stopwords.words("english")
# Empty list to store clean words :
clean_words = []
for w in words_no_punc:
    if w not in stopwords:
        clean_words.append(w)

fdist = FreqDist(clean_words)
print(fdist.most_common(10))
print(clean_words)
print("Before eliminating stop words, total no.of.tokens",len(words_no_punc))
print("After eliminating stop words, total no.of.tokens",len(clean_words))
#
#Frequency distribution :
fdist = FreqDist(clean_words)
fdist.most_common(10)

#Plot the most common words on grpah:
fdist.plot(10,title="After removing Stop words")

# Performing Stemming
snowball = SnowballStemmer("english")
#Word-list for stemming :
print("-------------------------------------Stemming---------------------------------------")
print("{0:20}{1:20}".format("Word","Snowball Stemmer"))


for w in clean_words:
    print("{0:20}{1:20}".format(w,snowball.stem(w)))
#
print(type(clean_words))
# Convert list of strings to string
clean_words_str = convert_list_to_string(clean_words)
print(type(clean_words_str))
print(clean_words_str)

# PoS tagging
# Tokenizing words :
tokenized_words = word_tokenize(clean_words_str)

for words in tokenized_words:
    tagged_words = nltk.pos_tag(tokenized_words)

print("-------------------------------------POS Tagging---------------------------------------")
print(tagged_words)


#Create an object :
cv = CountVectorizer()

#Generating output for Bag of Words :
B_O_W = cv.fit_transform(clean_words).toarray()

#Features :
# print(cv.get_feature_names())
# print("\n")
print("---------------------------------Building Bag-of-Words-------------------------------")
#Show the output :
print(B_O_W)
print(cv.get_feature_names())
#
print("---------------------------------Building TF-IDF Vectors-------------------------------")
#Create an object :
vectorizer = TfidfVectorizer(norm = None)

#Generating output for TF_IDF :
X = vectorizer.fit_transform(clean_words).toarray()

#Total words with their index in model :
# print(vectorizer.vocabulary_)
# print("\n")


#Show the output :
print(X)

#Features :
print(vectorizer.get_feature_names())
print("\n")

# Data Visualaization
# combining the image with the dataset
Mask = np.array(Image.open(requests.get('http://clipart-library.com/image_gallery2/Twitter-PNG-Image.png', stream=True).raw))
# We use the ImageColorGenerator library from Wordcloud
# Here we take the color of the image and impose it over our wordcloud
image_colors = ImageColorGenerator(Mask)

#Generating the wordcloud :
wordcloud = WordCloud(background_color='black', height=1500, width=4000,mask=Mask).generate(text)

#Plot the wordcloud :
plt.figure(figsize = (12, 12))
plt.imshow(wordcloud)

#To remove the axis value :
plt.axis("off")
plt.show()

# Generating Bar plots
print(vectorizer.vocabulary_)
keys = vectorizer.vocabulary_.keys()
values = vectorizer.vocabulary_.values()
plt.bar(range(len(vectorizer.vocabulary_)), list(vectorizer.vocabulary_.values()), align='center')
plt.xticks(range(len(vectorizer.vocabulary_)), list(vectorizer.vocabulary_.keys()),rotation=90)
plt.show()
