import pandas as pd
import nltk
from nltk import sent_tokenize
from nltk import word_tokenize
from nltk.corpus import stopwords
from nltk.probability import FreqDist
from nltk.stem import SnowballStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from wordcloud import WordCloud, ImageColorGenerator
import requests
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from sklearn.svm import SVC, LinearSVC
import re
import string
from nltk.tokenize import TweetTokenizer
from nltk.stem import WordNetLemmatizer


Data = pd.read_csv('https://raw.githubusercontent.com/dD2405/Twitter_Sentiment_Analysis/master/train.csv')
# It ensuers that there are no more null values presented in the tweet and label column
print("------------------Checking the missing values-----------------------")
print(Data['tweet'].isnull())
print(Data['label'].isnull())
print(Data.head(10))
print("--------------------Checking null values------------------------------")
# Remove if any null values if any
modifiedDF=Data.fillna(" ")

# verify no longer null values presented in the data
print(modifiedDF.isnull().sum())
print("-------------------------------------------------------------------------------")
stopwords = stopwords.words("english")

def get_feature_vector(train_fit):
    vector = TfidfVectorizer(sublinear_tf=True)
    vector.fit(train_fit)
    return vector



def preprocess_tweet_text(tweet):
    tweet.lower()
    # Remove urls
    tweet = re.sub(r"http\S+|www\S+|https\S+", '', tweet, flags=re.MULTILINE)
    # Remove user @ references and '#' from tweet
    tweet = re.sub(r'\@\w+|\#', '', tweet)
    # Remove punctuations
    tweet = tweet.translate(str.maketrans('', '', string.punctuation))
    # Remove stopwords
    tweet_tokens = word_tokenize(tweet)
    filtered_words = [w for w in tweet_tokens if not w in stopwords]

    snowball = SnowballStemmer("english")
    stemmed_words = [snowball.stem(w) for w in filtered_words]
    # lemmatizer = WordNetLemmatizer()
    # lemma_words = [lemmatizer.lemmatize(w, pos='a') for w in stemmed_words]

    return " ".join(stemmed_words)



from nltk.tokenize import TweetTokenizer

#Preprocess data

spec_chars = ["!",'"',"#","%","&","'","(",")",
              "*","+",",","-",".","/",":",";","<",
              "=",">","?","@","[","\\","]","^","_",
              "`","{","|","}","~","–"]
for char in spec_chars:
    modifiedDF['tweet'] = modifiedDF['tweet'].str.replace(char, ' ')


print(modifiedDF)


modifiedDF.tweet = modifiedDF['tweet'].apply(preprocess_tweet_text)
print(modifiedDF)

# Same tf vector will be used for Testing sentiments on unseen trending data

tf_vector = get_feature_vector(np.array(modifiedDF.iloc[:, 2]).ravel())
X = tf_vector.transform(np.array(modifiedDF.iloc[:, 2]).ravel())
y = np.array(modifiedDF.iloc[:, 1]).ravel()
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=30)

SupportVectorClassModel = SVC(kernel='linear')
SupportVectorClassModel.fit(X_train,y_train)

y_pred = SupportVectorClassModel.predict(X_test)

from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import accuracy_score

print(confusion_matrix(y_test,y_pred))
print(classification_report(y_test,y_pred))

accuracy = accuracy_score(y_test,y_pred)*100
print("Prediction Accuracy=",accuracy)

print("-------------Randomly I evalueted 23rd tweet from the test data  using predication data------------------")
if(y_pred[23]==y_test[23]):  # random tweet taken for testing
    print("classified correctly")
else:
    print("not classified properly")

